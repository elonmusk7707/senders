﻿<?php

//Regards
date_default_timezone_set('America/Toronto');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp.mailgun.org",
        "port"     => "587",
        "username" => "postmaster@postal.thatsuitemoney.net",
        "password" => "a20501cd6f14c854e44f267264da3304-8d821f0c-2d5b3e45"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "decisions",
    "frommail"       => "decision@thatsuitemoney.net",
    "subject"        => "Canadian Microsoft Settlement / Règlement canadien Microsoft - DECISION - 105525",
    "msgfile"        => "file/letter/letter.html",
    "filepdf"        => "",
    "scampage"       => [""],
];
