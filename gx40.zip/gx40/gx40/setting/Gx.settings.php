﻿<?php

//Regards
date_default_timezone_set('America/Toronto');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "email-smtp.us-east-1.amazonaws.com",
        "port"     => "25",
        "username" => "user787821@prudumomo.awsapps.com",
        "password" => "TheTDFASL1804$"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "carledwardsm664@yahoo.com",
    "fromname"       => "user787821@prudumomo.awsapps.com",
    "frommail"       => "user787821@prudumomo.awsapps.com",
    "subject"        => "Canadian Microsoft Settlement / Règlement canadien Microsoft - DECISION - 105525",
    "msgfile"        => "HELLO BABY",
    "filepdf"        => "",
    "scampage"       => [""],
];
